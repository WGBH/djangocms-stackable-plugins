
See the orig_README.md file for the real README.

For some reason this won't upload to PyPi with the actual README file.

